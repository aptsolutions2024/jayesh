

<script type="text/javascript" src="../js/script.js"></script>
<!--footer start -->

<footer class="twelve coptyright_bg"  id="footer">

        <div class="row">

            <div class="twelve columns">



                <!--First part starts here-->

            <div class="four columns text-left   mobicenter" id="container1">





            </div>

                <!--First part ends here-->

            <!--Second part starts here-->

            <div class="four columns text-center" id="container2">

                <div class="copyright" >All right reserved, Copyright © 2017 Salary Module</div>

            </div>

            <!--Second part ends here-->

            <!--Third part starts here-->

            <div class="four columns text-left  footer-text mobicenter" id="container3">



            </div>

                </div>

            <!--Third part ends here-->

        </div>



 </footer>

<!--footer end -->