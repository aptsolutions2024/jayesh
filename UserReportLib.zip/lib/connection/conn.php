<?php
/*$config = array('DBUSER'=>'aptsolution',
                'DBPASS'=>'sR91(o^o_sj}e',
                'DBHOST'=>'localhost',
                'DBNAME'=> 'salary_demo');*/	
/*$config = array('DBUSER'=>'aptsolutions',
                'DBPASS'=>'godaddy@2020',
                'DBHOST'=>'localhost',
                'DBNAME'=> 'dbsalary');*/
$config = array('DBUSER'=>'aptsolutions',
                'DBPASS'=>'godaddy@2020',
                'DBHOST'=>'localhost',
                'DBNAME'=> 'ghare');
	?> 